Select * from stg_Churn
